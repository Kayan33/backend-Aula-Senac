

interface Usuario {
    nome: string;
    email: string;
    password: string;
  }
  const usuarios: Usuario[] = []; 
  class UsuarioServices{
    
     async cadastrar_usuarios({nome,email,password}:Usuario){
        const cadastro:Usuario={nome,email,password}
        usuarios.push(cadastro)

     }}

  export {UsuarioServices}